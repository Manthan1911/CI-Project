﻿using StudentCRUDWeb.Entities.DataModels;
using StudentCRUDWeb.Entities.ViewModels;
using StudentCRUDWeb.Repositories.Repository.Interface;

namespace StudentCRUDWeb.Repositories.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private readonly StudentDbContext _studentDbContext;

        public StudentRepository(StudentDbContext studentDbContext)
        {
            _studentDbContext= studentDbContext;    
        }
        public IEnumerable<StudentModel> GetStudents()
        {
            return _studentDbContext.Students
                .Select(students => new StudentModel
                {
                    RollNo = students.RollNo,
                    Name = students.Name,
                    Department = students.Department,
                    Course = students.Course,
                });
        }
    }
}
