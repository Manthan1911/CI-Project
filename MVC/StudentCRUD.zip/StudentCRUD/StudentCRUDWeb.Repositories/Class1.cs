﻿namespace StudentCRUDWeb.Repositories
{
    public class Class1
    {

    }
}