﻿using StudentCRUDWeb.Entities.ViewModels;

namespace StudentCRUDWeb.Repositories.Repository.Interface
{
    public interface IStudentRepository
    {
        public IEnumerable<StudentModel> GetStudents();

    }
}
