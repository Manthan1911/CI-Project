﻿namespace StudentCRUDWeb.Entities
{
    public class Class1
    {

    }
}