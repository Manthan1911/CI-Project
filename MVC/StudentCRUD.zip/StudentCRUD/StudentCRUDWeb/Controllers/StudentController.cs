﻿using Microsoft.AspNetCore.Mvc;
using StudentCRUDWeb.Repositories.Repository.Interface;

namespace StudentCRUDWeb.Controllers
{
    public class StudentController : Controller
    {
        private readonly IStudentRepository _studentRepository;

        public StudentController(IStudentRepository studentRepository)
        {
                _studentRepository= studentRepository;  
        }

        //GET
        public IActionResult Index()
        {
            var students = _studentRepository.GetStudents();
            return View(students);
        }
    }
}
